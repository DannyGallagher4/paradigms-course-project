from django.urls import path

from . import views
app_name = 'game'  # creates a namespace for this app
urlpatterns = [
    path('login/', views.login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('home/', views.home, name='home'),
    path('logout/', views.logout_view, name='logout'),
    path('play/', views.play, name='play'),
    path('profile/', views.profile, name='profile'),
    path('buy-games/', views.buy_games, name='buy_games'),
    path('save-result/', views.save_game_result, name='save_result'),
    path('start-game/', views.start_game, name='start_game'),
]
